<div class="banner1">
    <div class="container">
        <h3><a href="index.php">Halaman Utama</a> </h3>
    </div>
</div>
<!--banner-->

<div class="content">
    <!--typography-page -->
    <div class="typo-w3">
        <div class="container">
            <!--<h2 class="tittle">Short Codes</h2>-->
            
            <!--<h3 class="bars">Forms</h3>-->
            <center>
            <h2 class="typoh2">Aplikasi Klasifikasi Karakteristik Kepribadian Manusia</h2>
            
            <h3 class="typoh2">dengan Metode Decision Tree C4.5</h3>
            </center>
        </div>
    </div>
    <!-- //typography-page -->

</div>